import { useEffect, useRef, useState } from "react"

type PracticeItem = {
  kana: string
  label: string
  stars: number
}

const practiceItems: PracticeItem[] = [
  { kana: "き", label: "ki", stars: 1 },
  { kana: "し", label: "shi", stars: 3 },
  { kana: "の あ", label: "Noah", stars: 3 },
  { kana: "ね こ", label: "neko", stars: 2 },
  { kana: "え ま", label: "Emma", stars: 3 },
]

function useMomentaryPress(duration = 240) {
  const [pressedId, setPressedId] = useState<string | null>(null)
  const timeoutRef = useRef<number | null>(null)

  useEffect(
    () => () => {
      if (timeoutRef.current !== null) {
        window.clearTimeout(timeoutRef.current)
      }
    },
    [],
  )

  const press = (id: string) => {
    if (timeoutRef.current !== null) {
      window.clearTimeout(timeoutRef.current)
    }

    setPressedId(id)
    timeoutRef.current = window.setTimeout(() => {
      setPressedId(null)
      timeoutRef.current = null
    }, duration)
  }

  return { pressedId, press }
}

function BackgroundDecor() {
  return (
    <svg
      className="background-decor"
      viewBox="0 0 1200 1000"
      preserveAspectRatio="xMidYMin slice"
      aria-hidden="true"
    >
      <g className="grain grain-top-left">
        <path d="M-80 102C38 138 73 22 186-15S350 5 405-84" />
        <path d="M-96 151C45 195 109 67 211 32S361 44 437-58" />
        <path d="M-94 209C48 248 126 127 226 91S383 100 462-19" />
      </g>
      <g className="grain grain-right">
        <path d="M1004-48c-31 105 98 122 57 224s62 149 154 117" />
        <path d="M1060-63c-34 98 83 129 53 225s42 144 135 138" />
        <path d="M1119-69c-30 87 72 120 55 205s31 129 111 130" />
      </g>
      <g className="grain grain-bottom">
        <path d="M-79 867c127-78 196 36 313-31s170 33 264 118" />
        <path d="M-99 931c143-88 223 26 335-30s168 27 263 115" />
        <path d="M936 848c80-36 128 56 206 13s130-11 181 55" />
        <path d="M909 902c91-44 144 48 221 16s126-3 186 66" />
      </g>
    </svg>
  )
}

function GearIcon() {
  return (
    <svg viewBox="0 0 48 48" aria-hidden="true">
      <path d="m20 5-1.2 5.3-4.2 1.8-4.6-2.9-4.8 4.8 2.9 4.6L6.3 23 1 24l1 6 5.4.9 1.8 4.3-2.9 4.6 4.8 4.8 4.6-2.9 4.3 1.8 1 5.3h6l1-5.3 4.3-1.8 4.6 2.9 4.8-4.8-2.9-4.6 1.8-4.3L47 30l1-6-5.3-1-1.8-4.3 2.9-4.6L39 9.3l-4.6 2.9-4.3-1.8L29 5Z" />
      <circle cx="24" cy="27" r="7" />
    </svg>
  )
}

function WriteIcon() {
  return (
    <svg viewBox="0 0 52 52" aria-hidden="true">
      <path className="speech" d="M6 10h36v22H24l-9 8v-8H6z" />
      <path className="pencil" d="m29 35 12-12 4 4-12 12h-4z" />
      <path className="writing-line" d="M34 42h12" />
    </svg>
  )
}

function LetterIcon() {
  return (
    <div className="letter-icon" aria-hidden="true">
      あ
    </div>
  )
}

function SpeakerIcon() {
  return (
    <svg viewBox="0 0 48 48" aria-hidden="true">
      <path d="M8 19h7l10-8v26l-10-8H8z" />
      <path className="sound-wave" d="M32 17a10 10 0 0 1 0 14" />
    </svg>
  )
}

function Star({ filled }: { filled: boolean }) {
  return (
    <svg
      className={filled ? "star star-filled" : "star"}
      viewBox="0 0 48 48"
      aria-hidden="true"
    >
      <path d="m24 4 6 13 14 1.6-10.5 9.6 3 14L24 35l-12.5 7.2 3-14L4 18.6 18 17z" />
    </svg>
  )
}

function PracticeCard({
  item,
  pressed,
  onPress,
}: {
  item: PracticeItem
  pressed: boolean
  onPress: () => void
}) {
  return (
    <button
      className={`practice-card${pressed ? " is-pressed" : ""}`}
      type="button"
      onClick={onPress}
      aria-label={`${item.kana}, ${item.label}. Play pronunciation`}
    >
      <span className="practice-kana">{item.kana}</span>
      <span className="practice-label">{item.label}</span>
      <span className="stars" aria-label={`${item.stars} out of 3 stars`}>
        {[1, 2, 3].map((star) => (
          <Star key={star} filled={star <= item.stars} />
        ))}
      </span>
      <span className="speaker">
        <SpeakerIcon />
      </span>
    </button>
  )
}

function ChoiceCard({
  variant,
  title,
  pressed,
  onPress,
}: {
  variant: "word" | "letter"
  title: string
  pressed: boolean
  onPress: () => void
}) {
  return (
    <button
      className={`choice-card choice-${variant}${pressed ? " is-pressed" : ""}`}
      type="button"
      onClick={onPress}
    >
      {variant === "word" ? <WriteIcon /> : <LetterIcon />}
      <span>{title}</span>
    </button>
  )
}

export default function App() {
  const { pressedId, press } = useMomentaryPress()

  return (
    <div className="page">
      <BackgroundDecor />
      <main className="app-shell">
        <header className="home-header">
          <div className="brand-lockup">
            <div className="brand">
              <h1>
                <span>Hiragana</span> <span>Buddy</span>
              </h1>
              <p>ひらがな の ともだち</p>
            </div>
            <img
              className="mascot"
              src="/mascot-happy.svg"
              alt="Smiling Hiragana Buddy mascot"
            />
          </div>
          <button
            className={`settings-button${
              pressedId === "settings" ? " is-pressed" : ""
            }`}
            type="button"
            aria-label="Open settings"
            onClick={() => press("settings")}
          >
            <GearIcon />
          </button>
        </header>

        <section className="choice-grid" aria-label="Choose a practice mode">
          <ChoiceCard
            variant="word"
            title="Write a word"
            pressed={pressedId === "word"}
            onPress={() => press("word")}
          />
          <ChoiceCard
            variant="letter"
            title="One letter"
            pressed={pressedId === "letter"}
            onPress={() => press("letter")}
          />
        </section>

        <section className="practice-grid" aria-label="Practised words">
          {practiceItems.map((item) => {
            const id = `practice-${item.label}`

            return (
              <PracticeCard
                key={item.label}
                item={item}
                pressed={pressedId === id}
                onPress={() => press(id)}
              />
            )
          })}
        </section>
      </main>
    </div>
  )
}
