# Hiragana Buddy Homepage Aesthetic Refresh Plan

## Objective
Refresh the existing homepage so it more closely matches the uploaded aesthetic concept and palette while preserving the established mobile/tablet information architecture, current practice data, and visual-only interaction scope.

## Confirmed product decisions
- Include **simplified decorative background elements** inspired by the concept.
- Replace the current sun icon with a **gear/settings icon**.
- Keep the existing responsive structure: two columns on mobile and four columns for practice cards on tablet, including portrait and landscape layouts.
- Keep all interactions visual-only; do not add routing, audio playback, settings behavior, or data persistence.
- Retain the five current practice entries and their existing three-star rating scale rather than adopting the concept image’s four-star presentation.
- Apply the temporary press effect to the settings control, both mode cards, and each practice card as a whole.

## Files to change
- `src/App.tsx`
- `src/index.css`

No new dependencies or image assets are required. Continue using `public/mascot-happy.svg` and the existing Google Fonts import for Klee One and Nunito.

## Implementation plan

### 1. Add reusable React press-state behavior in `src/App.tsx`
- Import the React hooks needed for state, timer storage, and cleanup.
- Add a small `useMomentaryPress` hook that:
  - Stores the currently pressed control ID.
  - Applies the state for approximately 240 ms whenever a control is activated.
  - Clears/restarts the timeout on repeated activation so rapid taps remain deterministic.
  - Cleans up the timeout when the component unmounts.
- Keep the interaction state centralized in `App` and pass `pressed`/`onPress` props into mode and practice card components.
- Trigger the state from each control’s `onClick`, which covers pointer activation and keyboard activation without relying on CSS `:active`.
- Add an `is-pressed` class only while a control’s ID is active.

### 2. Update component semantics and icons in `src/App.tsx`
- Replace `SunIcon` with a custom inline `GearIcon` that uses the same rounded, hand-drawn visual language as the rest of the interface.
- Keep the existing inline write, letter, speaker, and star artwork, but adjust SVG class hooks as needed for the new outlined/tactile treatment.
- Render each practice card as a `button` instead of a passive `article` so the whole tile has consistent keyboard and click behavior. Preserve the star rating’s accessible text.
- Give each visual-only control a clear accessible label:
  - Settings button: “Open settings”.
  - Mode buttons: their visible titles.
  - Practice cards: include the label/kana and that activation would play pronunciation, without claiming playback actually occurs.
- Add `aria-pressed` only if it accurately describes the momentary visual state; otherwise keep the transient state purely presentational to avoid implying a persistent toggle.

### 3. Introduce simplified decorative scenery
- Add a presentational `BackgroundDecor` component before the page content, marked `aria-hidden="true"` and excluded from pointer events.
- Use one lightweight inline SVG or grouped CSS/SVG shapes to create:
  - Low-contrast curved wood-grain contour lines at the outer corners/edges.
  - A few compact pebble clusters using the palette’s brown, green, cyan, and neutral tones.
  - Small two-leaf sprouts near selected pebble clusters.
- Keep decorations behind the content with controlled z-index and clipping at the viewport edges.
- Reduce or hide the busiest side clusters on narrow phones so decorations never compete with text or controls.

### 4. Rework the visual system in `src/index.css`
- Define a compact set of custom properties based on the supplied palette, including:
  - Warm cream canvas and light cream card surface.
  - Charcoal-brown outline/text color.
  - Deep green brand color.
  - Peach/orange word-mode colors.
  - Cyan/blue letter-mode colors.
  - Warm brown/tan raised edges and audio controls.
  - Coral/purple accents reserved for subtle decoration, not primary controls.
- Replace the current soft gradient background with a flatter warm cream canvas and understated texture/decor layers closer to the concept.
- Maintain Nunito for Latin UI copy and Klee One for kana.

### 5. Restyle the header
- Make the header feel more compact and centered, with the mascot acting as a small brand companion rather than a large leading block.
- Color the title deep green and increase its rounded, friendly weight.
- Preserve a mobile-safe arrangement: compact mascot/title grouping on the left and the settings control on the right; allow the title to stack only where needed.
- Style the gear as a circular tan/brown tactile button with a dark outline, lower raised edge, and soft cast shadow.

### 6. Restyle the two mode cards
- Preserve the two-column layout on mobile and tablet.
- Use stronger dark outlines, larger corner radii, subtle top highlights, and visibly deeper lower edges to match the concept’s toy-like construction.
- Word mode: peach face with orange/brown lower edge and dark icon/title.
- Letter mode: cyan face with blue/teal lower edge; place the kana in a raised cream inset tile.
- Keep card titles readable and prevent wrapping at supported widths; scale icon and type dimensions with responsive CSS rather than changing the copy.

### 7. Restyle the practice cards
- Use warm cream faces with dark brown outlines, large rounded corners, a tan lower edge, and a restrained shadow.
- Increase kana prominence while keeping labels and ratings compact enough for two-column mobile cards.
- Preserve three stars per card and existing ratings; restyle filled stars in warm orange/gold and empty stars in a muted neutral.
- Replace the flat lower speaker row with a compact inset/raised tan audio pill or rounded square, visually matching the concept while remaining part of the whole-card button.
- Remove the current divider if the inset speaker control provides sufficient grouping.

### 8. Implement the tactile press treatment
- Add a shared `.is-pressed` treatment for settings, mode, and practice controls:
  - `transform: translateY(4px)`.
  - Approximately 10% visual darkening using `filter: brightness(0.9)`.
  - Reduce the lower-edge shadow/offset so the control appears physically depressed rather than merely shifted.
- Keep the state duration near 240 ms and use short easing for entry/return.
- Under `prefers-reduced-motion: reduce`, remove animated interpolation but retain the immediate pressed-state position/darkening so feedback remains visible.
- Preserve clear `:focus-visible` outlines with sufficient contrast against every card color.

### 9. Responsive behavior
- Keep the app centered with a practical maximum width, but allow the decorative canvas to span the viewport.
- Mobile portrait:
  - Two mode columns and two practice columns.
  - Compact gaps/padding that still support a 320 px minimum width.
  - Simplified/partially hidden decoration clusters.
- Tablet portrait and landscape:
  - Two mode columns and four practice columns.
  - More generous horizontal spacing and larger header/title treatment.
  - Show the fuller set of edge decorations where they do not overlap content.
- Ensure the fifth practice card wraps naturally on tablet without forcing a desktop-only five-column grid.

## Verification
Because this is a broader visual and interaction update across both source files:
1. Run the repository’s formatter via `pnpm format` and confirm only intended formatting changes occur.
2. Run `pnpm build` and require a successful Vite/TypeScript production build.
3. Inspect the existing hot-reloaded preview at representative widths:
   - 320–390 px phone portrait.
   - Approximately 768 px tablet portrait.
   - Approximately 1024 px tablet landscape.
4. Confirm visually that:
   - Content does not overlap the gear or decorations.
   - Mode titles remain legible and unwrapped where intended.
   - The practice grid remains two columns on mobile and four on tablet.
   - Every settings/mode/practice control visibly depresses by 4 px, darkens, and returns after about 240 ms.
   - Keyboard activation triggers the same feedback and focus rings remain visible.
   - Reduced-motion mode removes interpolation without removing feedback.
5. Confirm no navigation, sound, theme mutation, or other functional side effects were introduced.

## Out of scope
- Real pronunciation audio.
- Navigation into practice modes.
- Settings or theme panels.
- Progress editing or persistence.
- Replacing the existing mascot asset with the concept image’s mascot.
- Reproducing every decorative object or making the desktop concept’s five-column layout the tablet layout.
