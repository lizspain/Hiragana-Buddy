# Plan: Add Consistent Press Feedback to Homepage Controls

## Goal
Add polished, momentary clicked feedback to the homepage’s two practice-mode buttons, Settings button, reusable practice cards, and each card’s sound button while preserving the current layout and reference styling.

## Confirmed Interaction Specification
- Every requested interactive target depresses by exactly 4px while its feedback is active: `transform: translateY(4px)`.
- Every requested target darkens by 10% while active: `filter: brightness(0.9)`.
- Feedback is momentary and returns automatically; no target remains selected.
- “Write a word” and “One letter” do not navigate or start workflows.
- Settings does not open a panel or change the theme.
- Practice-card activation does not navigate or change card data.
- Sound controls do not play audio; they provide the same visual press feedback only.

## Current Implementation Context
- `src/App.tsx` contains the icon components, reusable `ChoiceCard`, reusable `PracticeCard`, static `practiceItems`, and homepage composition.
- `src/index.css` owns all component styling and responsive behavior.
- The two primary choices and Settings are already native `<button>` elements.
- Practice cards are currently non-interactive `<article>` elements, and their sound areas are non-interactive `<div>` elements.
- Existing bottom shadows are 6px on the large mode buttons and 4px on Settings and practice cards.
- The project uses React 19, TypeScript, Vite, and CSS/Tailwind v4 without a test framework.

## Implementation Plan

### 1. Add reusable transient press state
- In `src/App.tsx`, add a small reusable React hook that returns an active boolean and an activation callback.
- On activation, set the visual state immediately and clear it after a short fixed interval (approximately 220–250 ms), keeping the feedback visible after mouse, touch, or keyboard activation instead of relying only on the fleeting CSS `:active` pseudo-class.
- Clear an existing timeout before starting a replacement so rapid clicks restart the feedback cleanly.
- Clean up pending timeouts on unmount.
- Keep state local to each interactive target so presses do not create persistent or shared selection state.

### 2. Apply the exact effect to the two primary mode buttons
- Extend `ChoiceCard` so each native button triggers its own transient state.
- Apply a shared pressed class while feedback is active.
- In `src/index.css`, make the pressed class:
  - translate the button down exactly 4px;
  - apply `filter: brightness(0.9)`;
  - reduce the existing 6px bottom shadow to 2px so the visual base remains aligned with the 4px depression.
- Keep current dimensions, labels, variants, focus-visible styling, and layout unchanged.
- Change the cursor from the current default to pointer.

### 3. Apply the exact effect to Settings
- Add transient state to the existing Settings button.
- While active, translate it down exactly 4px and apply `filter: brightness(0.9)`.
- Collapse its existing 4px solid bottom shadow to 0 while retaining, or subtly reducing, the soft ambient shadow so the button reads as physically pressed.
- Do not rotate, scale, replace, or otherwise animate the sun icon.
- Keep `aria-label="Theme settings"`; do not change the icon, page colors, or theme.

### 4. Make each practice card and sound control independently interactive
- Preserve `PracticeCard` as the reusable data-driven component.
- Refactor each card into a semantic `<article>` shell with two sibling native buttons:
  - a main card-action button containing kana, label, stars, and divider;
  - a sound button containing the speaker icon.
- Avoid nested buttons and click-propagation workarounds so each action is an independent keyboard target.
- Give the main action an accessible label such as `Practice き (ki)`.
- Give the sound action an accessible label such as `Play sound for き (ki)`, despite this iteration being visual-only.
- Preserve the current card grid rows, dimensions, clipping, and rounded silhouette by resetting inner button defaults.

#### Main practice-card feedback
- Drive the transient state from the main card-action button, but place the visual pressed class on the whole card shell so the complete card depresses as one object.
- Translate the whole card down exactly 4px and apply `filter: brightness(0.9)`.
- Collapse the card’s existing 4px bottom shadow to 0 during the press.
- The sound button must not trigger this card-level state.

#### Sound-button feedback
- Give each sound button its own transient state.
- Translate only the sound button/icon area down exactly 4px and apply `filter: brightness(0.9)`.
- Do not add pulse, wave, rotation, or scale animation; the requested depression and darkening are the complete feedback.
- Activating sound must not activate the practice-card state.

### 5. Define consistent interaction and accessibility CSS
- Use a shared transition duration/easing for transform, filter, and box-shadow so all targets feel consistent.
- Add hover affordances only if they do not conflict with the exact pressed effect; no hover transform or darkening is required.
- Extend `:focus-visible` coverage to the practice-card action and sound button, using rounded outlines that remain visible and are not clipped.
- Reset default button borders, backgrounds, padding, text color, and font only within the new practice-card button classes.
- Avoid any dimensional changes, margin changes, or reflow during feedback; transforms and shadow changes are visual-only.
- In the existing `prefers-reduced-motion: reduce` block, remove transition animation while retaining the instantaneous 4px translated state and 10% darkening because they communicate activation rather than decorative motion.

## Edge Cases and Behavior
- Rapid repeat clicks restart the short feedback timer rather than accumulating timers.
- Different targets may display feedback simultaneously because state is component-local.
- Activating a sound button affects only that sound button, not the surrounding card.
- Keyboard activation through Enter or Space produces the same transient feedback and preserves visible focus.
- Existing phone/tablet breakpoints, card sizes, and grid positions remain unchanged.
- No audio APIs, browser permissions, routes, storage, theme state, or new dependencies are introduced.

## Files to Change
- `src/App.tsx`
  - import the required React hooks;
  - add reusable transient-press logic;
  - wire active state into Settings and `ChoiceCard`;
  - refactor `PracticeCard` into independent card-action and sound buttons with accessible labels and separate transient states.
- `src/index.css`
  - add the exact 4px depression, 10% darkening, shadow adjustments, pointer, focus-visible, transition, and reduced-motion styles;
  - adjust practice-card internals to preserve the current layout after semantic button refactoring.

## Verification
1. Run the repository formatter with `pnpm format`; inspect the diff afterward and retain only task-related formatting changes.
2. Run `pnpm build` to verify TypeScript, JSX, CSS processing, and production bundling.
3. In the existing preview, manually verify at phone and tablet widths:
   - both mode buttons move down exactly 4px, darken by 10%, and return;
   - Settings moves down exactly 4px, darkens by 10%, and returns without changing theme;
   - each card moves down exactly 4px as a complete object, darkens by 10%, and returns;
   - each sound button independently moves down exactly 4px, darkens by 10%, and returns without activating its card;
   - Enter and Space trigger the same feedback on every focusable control;
   - focus outlines are visible and not clipped;
   - rapid repeated clicks recover correctly;
   - layout, spacing, and responsive column counts remain unchanged.
4. Enable reduced-motion emulation and confirm the state still appears instantly with the same 4px depression and 10% darkening, but without an animated transition.
