# Fix Homepage Press Feedback

## Goal

Make every intended homepage control visibly respond when clicked or tapped, while preserving the existing visual layout and deliberately keeping the interactions non-functional beyond feedback.

## Current-State Diagnosis

- `src/App.tsx` currently renders the controls without click handlers or pressed-state props/classes.
- `src/index.css` includes `transition: transform 160ms ease` only for `.choice-card`, but no selector ever changes its transform.
- The theme control and practice cards have no transition or pressed styling.
- The speaker area is a non-interactive `<div>`, and the practice card is a non-interactive `<article>`.
- Therefore, the browser preview is behaving as implemented: clicks have no visible effect because the previously approved interaction work has not yet been applied.

## Interaction Contract

Apply the same momentary visual feedback to:

1. The “Write a word” mode button.
2. The “One letter” mode button.
3. The theme/settings button.
4. Each practice card.
5. Each practice card’s speaker button.

For every target:

- On activation, move the target down exactly `4px` using `transform: translateY(4px)`.
- Darken it by 10% using `filter: brightness(0.9)`.
- Keep the state visible for approximately `240ms`, even for a quick click/tap, so it can be perceived in the preview.
- Return automatically to the normal state.
- Do not navigate, play audio, toggle theme, select a card, or persist any state.
- Repeated activation of the same target during the feedback window restarts the timer, so the latest click receives a full feedback interval.
- Different targets maintain independent transient state, so activating the speaker does not visually press its parent card.

## Implementation Plan

### 1. Add a reusable transient press hook in `src/App.tsx`

Create a small local hook, `useMomentaryPress`, that:

- Uses `useState(false)` for the current pressed state.
- Uses `useRef` to retain the active timeout ID.
- Exposes an activation callback that:
  - clears any existing timeout,
  - sets the pressed state to `true`, and
  - schedules it to return to `false` after `240ms`.
- Uses `useEffect` cleanup to clear the timeout when the owning component unmounts.
- Returns the boolean state and activation callback for use by each independently interactive component.

This explicit timed state is preferred over CSS-only `:active`, because mouse clicks can be too brief to perceive and touch browsers may handle `:active` inconsistently.

### 2. Wire the two mode buttons

Update `ChoiceCard` so each rendered button:

- Owns its own `useMomentaryPress` instance.
- Calls the activation callback from `onClick`.
- Adds a shared `is-pressed` class while active.
- Sets `aria-pressed` only if semantically appropriate; because this is momentary feedback and not a persistent toggle, omit `aria-pressed` and retain normal button semantics.

No action beyond the visual feedback should occur.

### 3. Wire the theme/settings button

Extract the header theme button into a small local component or initialize its press state in `App`, choosing the smallest readable option.

- Keep `type="button"` and the existing `aria-label="Theme settings"`.
- Add `onClick` and the conditional `is-pressed` class.
- Do not alter theme state.

### 4. Make each practice card an accessible independent control

Change the interactive root of `PracticeCard` from `<article>` to `<button type="button">` while retaining the `practice-card` class and current internal layout.

- Give each card its own momentary press hook.
- Add a descriptive accessible label such as `Practice {label}` while preserving visible content.
- Add `onClick` and the conditional `is-pressed` class.
- Reset browser button defaults needed to preserve the current card appearance, including inherited font, text color, and border.

Using a real button avoids non-semantic click handlers and provides keyboard activation automatically.

### 5. Make the speaker area its own nested-safe button

HTML does not permit a `<button>` inside another `<button>`. To preserve independent card and speaker controls:

- Keep the practice card’s visual surface and semantics without nesting buttons by structuring each grid item as a wrapper containing:
  - a card-level button responsible for the card activation area/content, and
  - a separately positioned speaker button aligned into the existing bottom speaker region.
- Preserve the current card’s single-surface appearance, divider placement, dimensions, rounded corners, and shadow.
- Ensure the speaker button’s click does not activate the card button because the controls are siblings, not nested descendants.
- Give the speaker button a specific accessible label, e.g. `Play pronunciation for {label}`.
- Give each speaker button its own momentary press hook and conditional `is-pressed` class.

The exact wrapper class names can follow the existing naming style, but the resulting DOM must remain valid and keyboard accessible.

### 6. Add shared pressed styling in `src/index.css`

Introduce a shared selector for all interactive targets, or a reusable class applied to them, with:

- A transition covering both `transform` and `filter` (approximately `120–160ms ease`).
- `.is-pressed` applying:
  - `transform: translateY(4px)`
  - `filter: brightness(0.9)`
- `will-change` is unnecessary for this small interface and should be omitted unless rendering evidence requires it.

Also:

- Change button cursors from `default` to `pointer` for mouse affordance.
- Add focus-visible styling to the card and speaker controls consistent with the existing dark green outline used by the mode and theme controls.
- Preserve existing shadows rather than changing them; the whole target moves, so the requested exact 4px depression remains visually straightforward.
- In `prefers-reduced-motion: reduce`, remove the transition but retain the instantaneous transform and brightness change so feedback remains visible without animation.
- Add `touch-action: manipulation` to interactive controls to improve touch responsiveness without changing behavior.

## Accessibility and Event Behavior

- All controls use native `<button type="button">` semantics.
- Keyboard Enter/Space activation triggers the same `onClick` path and momentary feedback.
- Focus-visible outlines remain visible and consistent.
- The card and speaker controls are separate siblings to avoid invalid nested interactive elements and accidental double activation.
- No persistent selected/toggled semantics are announced because no persistent state exists.

## Scope

Files to modify:

- `src/App.tsx`
- `src/index.css`

No new assets, dependencies, routes, audio files, theme logic, or persistent application state will be added.

## Verification

1. Run the repository’s build command: `pnpm build`.
2. In the existing browser preview, activate each target with a mouse/tap:
   - both mode buttons,
   - theme/settings button,
   - at least two practice cards,
   - at least two speaker buttons.
3. Confirm each activated target independently moves down 4px and darkens for about 240ms, then returns to normal.
4. Confirm quick clicks still show visible feedback.
5. Confirm repeated clicks restart the feedback interval without leaving the target stuck.
6. Confirm a speaker activation does not also press its card.
7. Confirm no target navigates, plays audio, changes theme, or remains selected.
8. Keyboard-check all controls with Tab plus Enter/Space and confirm focus outlines remain visible.
9. Check mobile and tablet viewport widths to ensure the wrapper/button restructuring does not alter the 2-column/4-column layout, card dimensions, divider, speaker alignment, rounded corners, or shadows.
10. With reduced motion enabled, confirm the state change remains visible but occurs without transition animation.
